# Kids Book
A mobile-friendly children's learning website starter.
Open index.html to run it locally. Deploy the folder as a static site on Render or another static host.
